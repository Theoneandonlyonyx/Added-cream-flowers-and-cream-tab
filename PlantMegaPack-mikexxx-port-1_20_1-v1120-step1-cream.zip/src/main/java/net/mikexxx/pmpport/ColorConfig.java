package net.mikexxx.pmpport;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Colour categories for the "All Plants" tab. On first start the file
 * config/pmp_mikexxx_colortab.json is created from the built-in defaults. Edit it to move plants
 * between categories: cut a line and paste it into another colour list. Every line looks like
 * "flower_red   # Red Poppy (Papaver rhoeas)" - only the id in front of the '#' counts, the rest is a
 * readable comment. Plants that are missing from the file are added to "other".
 * When a new version of the mod ships improved defaults (_version goes up), the old file is saved as
 * plant_colors.old-vN.json and a fresh one is written.
 */
public final class ColorConfig {
    /** bump when the built-in defaults change so existing config files are regenerated (old one is kept as backup) */
    public static final int CONFIG_VERSION = 7;
    public static final String[] KEYS = {"burgundy", "red", "orange", "yellow", "cream", "green", "blue", "cyan", "purple", "pink", "white", "other"};
    private static final Map<String, List<ResourceLocation>> CATS = new LinkedHashMap<>();
    private static final List<ResourceLocation> ALL = new ArrayList<>();
    private static boolean loaded = false;

    private ColorConfig() {}

    private static JsonObject readDefaults() {
        try (InputStream in = ColorConfig.class.getResourceAsStream("/pmp_mikexxx_colortab.json")) {
            if (in == null) return new JsonObject();
            return JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
        } catch (Exception e) {
            return new JsonObject();
        }
    }

    /**
     * "pmp_mikexxx:flower_red   # Red Poppy (Papaver rhoeas)"  ->  "pmp_mikexxx:flower_red"
     * An id without a namespace belongs to this mod; any other id (minecraft:dandelion, somemod:rose ...) is used as it is.
     */
    static String idOf(String entry) {
        String id = entry;
        int hash = id.indexOf('#');
        if (hash >= 0) id = id.substring(0, hash);
        id = id.trim();
        if (id.isEmpty()) return id;
        return id.indexOf(':') >= 0 ? id : PmpMod.MODID + ":" + id;
    }

    private static List<String> list(JsonObject o, String key) {
        List<String> out = new ArrayList<>();
        if (o.has(key) && o.get(key).isJsonArray()) {
            for (JsonElement e : o.getAsJsonArray(key)) {
                String id = idOf(e.getAsString());
                if (!id.isEmpty() && ResourceLocation.tryParse(id) != null) out.add(id);
            }
        }
        return out;
    }

    private static Map<String, String> readNames() {
        Map<String, String> names = new java.util.HashMap<>();
        try (InputStream in = ColorConfig.class.getResourceAsStream("/assets/pmp_mikexxx/lang/en_us.json")) {
            if (in == null) return names;
            JsonObject lang = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            for (Map.Entry<String, JsonElement> en : lang.entrySet()) {
                String k = en.getKey();
                String pre = k.startsWith("block.pmp_mikexxx.") ? "block.pmp_mikexxx." : k.startsWith("item.pmp_mikexxx.") ? "item.pmp_mikexxx." : null;
                if (pre != null) names.putIfAbsent(k.substring(pre.length()), en.getValue().getAsString());
            }
        } catch (Exception ignored) { }
        return names;
    }

    private static Map<String, String> readLatin() {
        Map<String, String> latin = new java.util.HashMap<>();
        try (InputStream in = ColorConfig.class.getResourceAsStream("/pmp_entries.json")) {
            if (in == null) return latin;
            for (JsonElement e : JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonArray()) {
                JsonObject o = e.getAsJsonObject();
                if (o.has("latin") && !o.get("latin").isJsonNull()) latin.put(o.get("id").getAsString(), o.get("latin").getAsString());
            }
        } catch (Exception ignored) { }
        return latin;
    }

    private static JsonObject writeDefaults(Path dir, Path file, JsonObject defaults) throws java.io.IOException {
        Files.createDirectories(dir);
        Map<String, String> names = readNames();
        Map<String, String> latin = readLatin();
        JsonObject out = new JsonObject();
        out.addProperty("_version", CONFIG_VERSION);
        out.addProperty("_info", "Move plants between the colour filters of the PMP 'All Plants' creative tab: cut a line and paste it into "
                + "another colour list. Only the id in front of the '#' matters, the rest is just a readable comment. "
                + "You can also add any other item or block of the game or of other mods, written with its namespace, e.g. \"minecraft:dandelion\" or \"othermod:some_flower\". "
                + "The order of the lines is the order in the creative tab. A PMP plant that is not listed anywhere ends up in 'other'. Delete this file to get the defaults back.");
        for (String k : KEYS) {
            JsonArray a = new JsonArray();
            for (String id : list(defaults, k)) {
                StringBuilder sb = new StringBuilder(id);
                String path = id.startsWith(PmpMod.MODID + ":") ? id.substring(PmpMod.MODID.length() + 1) : null;
                String n = path == null ? null : names.get(path);
                String l = path == null ? null : latin.get(path);
                if (n != null || l != null) sb.append("   # ").append(n != null ? n : id);
                if (l != null) sb.append(" (").append(l).append(")");
                a.add(sb.toString());
            }
            out.add(k, a);
        }
        Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
        Files.write(file, gson.toJson(out).getBytes(StandardCharsets.UTF_8));
        return out;
    }

    public static synchronized void load() {
        if (loaded) return;
        loaded = true;
        JsonObject defaults = readDefaults();
        JsonObject user = defaults;
        try {
            Path dir = FMLPaths.CONFIGDIR.get();
            Path file = dir.resolve("pmp_mikexxx_colortab.json");
            if (!Files.exists(file)) {
                user = writeDefaults(dir, file, defaults);
            } else {
                JsonObject existing;
                try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                    existing = JsonParser.parseReader(r).getAsJsonObject();
                }
                int version = existing.has("_version") ? existing.get("_version").getAsInt() : 0;
                if (version < CONFIG_VERSION) {
                    // new defaults shipped: keep the player's old file as a backup and write the new one
                    Files.move(file, dir.resolve("pmp_mikexxx_colortab.old-v" + version + ".json"), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    user = writeDefaults(dir, file, defaults);
                } else {
                    user = existing;
                }
            }
        } catch (Exception e) {
            user = defaults;
        }
        Set<String> seen = new LinkedHashSet<>();
        for (String k : KEYS) {
            List<ResourceLocation> l = new ArrayList<>();
            for (String id : list(user, k)) {
                if (seen.add(id)) l.add(new ResourceLocation(id));
            }
            CATS.put(k, l);
        }
        // PMP plants that the player's file does not list (e.g. plants added by a mod update) go to "other"
        for (String k : KEYS) {
            for (String id : list(defaults, k)) {
                if (seen.add(id)) CATS.get("other").add(new ResourceLocation(id));
            }
        }
        // the whole tab = the colour groups one after another, in the order of the file
        for (String k : KEYS) ALL.addAll(CATS.get(k));
    }

    public static List<ResourceLocation> all() {
        load();
        return ALL;
    }

    public static List<ResourceLocation> category(String key) {
        load();
        if ("all".equals(key)) return ALL;
        List<ResourceLocation> l = CATS.get(key);
        return l == null ? new ArrayList<>() : l;
    }
}
